<?php
header('Content-Type: application/json');

try {
    // Database connection
    $dsn = 'mysql:host=localhost;dbname=vrified';
    $username = 'root'; // Replace with your DB username
    $password = ''; // Replace with your DB password
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Capture POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $firstName = htmlspecialchars($data['firstName']);
    $lastName = htmlspecialchars($data['lastName']);
    $birthday = $data['birthday'];
    $gender = $data['gender'];
    $email = htmlspecialchars($data['email']);
    $password = password_hash($data['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Email already exists']);
        exit;
    }

    // Insert user into database
    $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, birthday, gender, email, password_hash) VALUES (:first_name, :last_name, :birthday, :gender, :email, :password_hash)");
    $stmt->execute([
        'first_name' => $firstName,
        'last_name' => $lastName,
        'birthday' => $birthday,
        'gender' => $gender,
        'email' => $email,
        'password_hash' => $password
    ]);

    echo json_encode(['status' => 'success', 'message' => 'Registration successful!']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>