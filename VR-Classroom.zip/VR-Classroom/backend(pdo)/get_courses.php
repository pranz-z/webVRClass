<?php
header('Content-Type: application/json');

try {
    // Database connection
    $dsn = 'mysql:host=localhost;dbname=vrified';
    $username = 'root';
    $password = '';
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Capture user ID
    $userId = $_GET['userId'];

    // Get courses for user
    $stmt = $pdo->prepare("
        SELECT c.course_code, c.course_name, c.section, c.instructor
        FROM user_courses uc
        JOIN courses c ON uc.course_id = c.id
        WHERE uc.user_id = :user_id
    ");
    $stmt->execute(['user_id' => $userId]);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'courses' => $courses]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>