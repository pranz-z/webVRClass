<!DOCTYPE html>
<>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<div class="vr-classroom">
    <h1>Welcome to VR Classroom!</h1>
    <p>A world of immersive learning awaits you.</p>

    <div class="buttons">
        <button onclick="window.location.href='customize_profile.html'">Customize Profile</button>
        <button onclick="enterVRClassroom()">Enter VR Classroom</button>
    </div>

    <div class="logs-section">
        <h2>Recent Logs</h2>
        <div id="recentLogs" class="logs"></div>

        <h2>Recent Messages</h2>
        <div id="recentMessages" class="messages"></div>
    </div>
</div>
</body>
</html>












<?php
header('Content-Type: application/json');

try {
    // Database connection
    $dsn = 'mysql:host=localhost;dbname=vrified';
    $username = 'root';
    $password = '';
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Capture user ID
    $userId = $_GET['userId'];

    // Get session logs
    $stmt = $pdo->prepare("SELECT session_summary, session_date FROM session_logs WHERE user_id = :user_id ORDER BY session_date DESC LIMIT 5");
    $stmt->execute(['user_id' => $userId]);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get messages
    $stmt = $pdo->prepare("SELECT message_content, message_date FROM messages WHERE user_id = :user_id ORDER BY message_date DESC LIMIT 5");
    $stmt->execute(['user_id' => $userId]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'logs' => $logs, 'messages' => $messages]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>