<?php
header('Content-Type: application/json');

try {
    // Database connection
    $dsn = 'mysql:host=localhost;dbname=vrified';
    $username = 'root'; // Replace with your DB username
    $password = ''; // Replace with your DB password
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Capture POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $email = htmlspecialchars($data['email']);
    $password = $data['password'];

    // Retrieve user from database
    $stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if user exists and password is correct
    if ($user && password_verify($password, $user['password_hash'])) {
        // Successful login
        echo json_encode(['status' => 'success', 'message' => 'Login successful']);
    } else {
        // Invalid credentials
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password']);
    }

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
