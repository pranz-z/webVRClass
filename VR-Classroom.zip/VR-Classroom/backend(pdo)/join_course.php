<?php
header('Content-Type: application/json');

try {
    // Database connection
    $dsn = 'mysql:host=localhost;dbname=vrified';
    $username = 'root';
    $password = '';
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Capture POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $userId = $data['userId'];
    $classCode = htmlspecialchars($data['classCode']);

    // Find course by class code
    $stmt = $pdo->prepare("SELECT id FROM courses WHERE course_code = :course_code");
    $stmt->execute(['course_code' => $classCode]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$course) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid class code']);
        exit;
    }

    // Check if user is already enrolled
    $stmt = $pdo->prepare("SELECT id FROM user_courses WHERE user_id = :user_id AND course_id = :course_id");
    $stmt->execute(['user_id' => $userId, 'course_id' => $course['id']]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Already enrolled in this course']);
        exit;
    }

    // Enroll user in course
    $stmt = $pdo->prepare("INSERT INTO user_courses (user_id, course_id) VALUES (:user_id, :course_id)");
    $stmt->execute(['user_id' => $userId, 'course_id' => $course['id']]);

    echo json_encode(['status' => 'success', 'message' => 'Successfully joined the course']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>

